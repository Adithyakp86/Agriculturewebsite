


<!DOCTYPE html>
<html>
<head>
	<title>Agriculture</title>
	
<link rel="stylesheet" type="text/css" href="Styles/AgroCraft.css">	
<link href="https://fonts.googleapis.com/css?family=Cormorant+Infant&display=swap" rel="stylesheet">

</head>

<body >
	
	<div id ="WELCOME">WELCOME TO Agriculture Website <div id="are">ARE YOU A</div></h1>
	<span id="linebreak"></span>
	<label id="Farmerbutton"><a id = "link" href="auth/FarmerLogin.php">FARMER</a></label>
	<label id="Buyerbutton"><a id = "link" href="auth/BuyerLogin.php">BUYER</a></label>
	
</body>
</html>